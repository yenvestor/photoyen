# PhotoYen - Professional Photo Editor

A powerful, web-based photo editing application built with React, TypeScript, and Node.js. PhotoYen provides professional-grade image editing tools similar to Photoshop/Photopea, all running in your browser.

## 🎨 Features

### Core Drawing Tools
- **Brush Tool** - Full pressure sensitivity with size, opacity, flow, hardness controls
- **Pencil Tool** - Precise drawing with customizable size and opacity
- **Eraser Tool** - Smart erasing with size and opacity controls
- **Paint Bucket** - Intelligent flood fill with tolerance settings
- **Clone Stamp** - Professional cloning with Alt+click source selection

### Advanced Selection Tools
- **Rectangle Selection** - Precise rectangular selections with marching ants
- **Ellipse Selection** - Circular and elliptical selections
- **Lasso Selection** - Freehand selection drawing
- **Magic Wand** - Color-based selection with tolerance control

### Professional Text System
- **20+ Fonts** - Arial, Times, Georgia, Google Fonts and more
- **Full Formatting** - Size, weight, style, alignment controls
- **Text Effects** - Shadows, strokes, underline, strikethrough
- **Smart Layout** - Auto text wrapping and resizable text boxes

### Transform Operations
- **Rotate** - Any angle rotation with center point control
- **Scale** - Independent X/Y scaling
- **Flip** - Horizontal and vertical flipping
- **Skew** - Advanced skew transformations
- **Free Transform** - Combined rotation, scaling, and positioning
- **Perspective** - 4-point perspective distortion

### Image Adjustments
- **Brightness/Contrast** - Professional algorithms
- **Levels** - Input/output gamma correction
- **Hue/Saturation** - HSL color space adjustments
- **Exposure** - Professional exposure control
- **Vibrance** - Smart saturation enhancement
- **Threshold** - Binary threshold effects
- **Invert** - Color inversion
- **Posterize** - Color reduction effects

### Professional Filters
- **Artistic Effects** - Oil painting, watercolor, emboss
- **Blur Effects** - Gaussian blur, motion blur with directional control
- **Distortion** - Pinch, spherize, barrel distortion
- **Edge Detection** - Sobel edge detection algorithm
- **Stylize** - Solarize, emboss, and artistic effects

### Layer Management
- **Layer System** - Add, delete, reorder layers
- **Blend Modes** - Multiple blend mode options
- **Opacity Control** - Per-layer opacity adjustment
- **Layer Locking** - Protect layers from accidental edits
- **Drag & Drop** - Intuitive layer reordering

### Professional Workflow
- **Keyboard Shortcuts** - Full Photoshop-style shortcuts
- **Undo/Redo** - Comprehensive history management
- **Copy/Cut/Paste** - Full clipboard support with system integration
- **File Operations** - Import/export PNG, JPEG, WebP, GIF
- **Project Saving** - Save and load project files

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ 
- npm or yarn

### Installation

1. Clone the repository:
```bash
git clone <your-repo-url>
cd photoyen
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Open your browser to `http://localhost:5000`

## 🛠️ Development

### Project Structure
```
photoyen/
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── components/     # React components
│   │   ├── hooks/          # Custom React hooks
│   │   ├── store/          # Zustand state management
│   │   ├── types/          # TypeScript type definitions
│   │   └── utils/          # Utility functions
├── server/                 # Express.js backend
├── shared/                 # Shared types and utilities
└── package.json
```

### Key Technologies
- **Frontend**: React 18, TypeScript, Tailwind CSS, Zustand
- **Backend**: Node.js, Express.js, TypeScript
- **UI Components**: shadcn/ui
- **Canvas**: HTML5 Canvas API
- **Build Tool**: Vite

### Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm start` - Start production server
- `npm run check` - Type checking

## 🎯 Keyboard Shortcuts

### Tools
- `V` - Move Tool
- `M` - Marquee (Rectangle Select)
- `L` - Lasso Select  
- `W` - Magic Wand
- `B` - Brush Tool
- `E` - Eraser Tool
- `G` - Gradient Tool
- `S` - Clone Stamp
- `H` - Hand Tool
- `Z` - Zoom Tool
- `I` - Eyedropper
- `T` - Type Tool
- `U` - Shape Tools
- `P` - Pen Tool

### Operations
- `Ctrl+Z` - Undo
- `Ctrl+Y` - Redo
- `Ctrl+C` - Copy
- `Ctrl+V` - Paste
- `Ctrl+X` - Cut
- `Ctrl+N` - New Document
- `Ctrl+O` - Open
- `Ctrl+S` - Save

### Adjustments
- `[` / `]` - Decrease/Increase Brush Size
- `1-0` - Set Opacity (10%-100%)
- `D` - Default Colors
- `X` - Swap Colors
- `Ctrl+=` - Zoom In
- `Ctrl+-` - Zoom Out
- `Space` - Temporary Hand Tool

## 🌐 Deployment

### Railway Deployment

1. Push your code to GitHub
2. Connect your GitHub repo to Railway
3. Railway will automatically detect the `railway.toml` configuration
4. Deploy with one click!

The application includes:
- ✅ Railway configuration (`railway.toml`)
- ✅ Production build setup
- ✅ Environment variables handling
- ✅ Health check endpoints

### Manual Deployment

1. Build the project:
```bash
npm run build
```

2. Start the production server:
```bash
npm start
```

## 📄 License

This project is open source and available under the MIT License.

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 🐛 Bug Reports

If you find a bug, please open an issue on GitHub with:
- Description of the bug
- Steps to reproduce
- Expected behavior
- Screenshots (if applicable)

## 💡 Feature Requests

Have an idea for a new feature? Open an issue and describe:
- The feature you'd like to see
- Why it would be useful
- How it should work

---

Built with ❤️ using React, TypeScript, and the HTML5 Canvas API